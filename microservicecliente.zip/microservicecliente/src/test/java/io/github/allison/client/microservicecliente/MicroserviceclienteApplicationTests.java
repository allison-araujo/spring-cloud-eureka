package io.github.allison.client.microservicecliente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroserviceclienteApplicationTests {

	@Test
	void contextLoads() {
	}

}
