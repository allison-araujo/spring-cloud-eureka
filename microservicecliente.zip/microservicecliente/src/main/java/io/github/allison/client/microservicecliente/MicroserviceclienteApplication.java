package io.github.allison.client.microservicecliente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroserviceclienteApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceclienteApplication.class, args);
	}

}
